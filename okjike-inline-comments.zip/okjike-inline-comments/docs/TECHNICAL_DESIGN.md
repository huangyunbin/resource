# 极客（即刻 Web）动态页评论自动展开插件技术设计

## 1. 目标

- 在 `https://web.okjike.com/following` 阅读流中，为每条动态自动显示评论预览（默认前 3 条）。
- 评论区域插在动态卡片下方，不跳转详情页。
- 保持对登录态复用：不额外登录，不额外输入凭证。

## 2. 已验证前提（2026-02-25）

- 即刻 Web 前端使用以下接口：
  - `POST /1.0/comments/listPrimary`
  - `POST /1.0/comments/list`
  - `GET /1.0/comments/get`
  - `GET /1.0/originalPosts/get`
  - `GET /1.0/reposts/get`
- 鉴权 token 使用本地存储：
  - `localStorage["JK_ACCESS_TOKEN"]`
  - `localStorage["JK_REFRESH_TOKEN"]`
- 请求头：
  - `x-jike-access-token: <token>`
  - 刷新 token 时：`x-jike-refresh-token: <refreshToken>`
- 动态卡片根节点由前端代码渲染为：
  - `div[data-clickable-feedback="true"]`

## 3. 架构

- `Manifest V3`
- `content script` 注入到 `web.okjike.com`：
  - 监听卡片渲染（`MutationObserver`）
  - 卡片懒加载触发（`IntersectionObserver`）
  - 读取 token、请求评论接口
  - 渲染评论预览 UI
- 无后台 service worker（首版）
  - 理由：首版逻辑集中在页面内，减少通信复杂度

## 4. 关键技术方案

### 4.1 拿到每条动态的 `postId + targetType`

由于 feed 卡片 DOM 未直接暴露 `postId`，采用两层策略：

1. 主方案：读取 React Fiber 节点上的 `memoizedProps.data`（可拿到 `id/type`）
2. 兜底方案：从卡片内链接中提取 `/u/{username}/{post|repost}/{id}`（若存在）

> 备注：主方案对当前 React 渲染结构可行，但属于非公开实现细节；后续若 React 内部字段变化，自动回退到兜底方案。

### 4.2 token 获取与鉴权

- 每次请求前实时读取：
  - `localStorage.getItem("JK_ACCESS_TOKEN")`
  - `localStorage.getItem("JK_REFRESH_TOKEN")`
- 请求失败 401 时：
  1. 再次读取 token 后重试一次
  2. 若仍失败，调用 `/app_auth_tokens.refresh` 刷新
  3. 刷新成功后重试原请求
  4. 仍失败则在卡片内展示“请刷新页面或重新登录”

### 4.3 评论加载策略

- 首次进入视口时拉取：
  - `POST /1.0/comments/listPrimary`，参数：
    - `targetId`
    - `targetType`（`ORIGINAL_POST|REPOST|PERSONAL_UPDATE`）
    - `order: "LIKES"`
    - `limit: 20`
    - `loadMoreKey`
- UI 初始只渲染前 3 条。
- “展开更多”按钮按页加载。

### 4.4 缓存与频控

- 以内存 `Map` 缓存：
  - key: `${targetType}:${targetId}:LIKES`
  - value: `{ items, loadMoreKey, updatedAt }`
- TTL 默认 2 分钟，避免滚动重复拉取。
- 并发去重：同一 key 的 in-flight Promise 复用。

## 5. 异常与边界

- 未登录：token 缺失，显示“未登录或登录态失效”
- 接口变更：面板展示错误，控制台打印 response 快照
- 频率限制：显示“请求过于频繁”
- 卡片无法解析 `postId`：跳过，不影响其余卡片

## 6. 隐私与安全

- token 只驻留内存，不写入 `chrome.storage`
- 不上传外部服务，不做远端埋点
- 样式命名空间前缀统一 `jkic-`，避免污染站点样式

## 7. 目录规划

- `manifest.json`
- `src/content.js`
- `src/styles.css`
- `docs/TECHNICAL_DESIGN.md`
- `docs/TODO.md`
- `README.md`

## 8. 验收标准

- 打开 following 页后，滚动到动态卡片可自动看到评论区
- 至少 80% 有评论的卡片可成功渲染前 3 条评论
- token 过期后可自动刷新并恢复拉取
- 不出现明显页面卡顿（滚动正常）
