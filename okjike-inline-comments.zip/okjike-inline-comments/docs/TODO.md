# TODO - 即刻评论自动展开插件

## 0. 文档与脚手架

- [x] 输出技术设计文档
- [x] 初始化扩展目录与 manifest
- [x] 编写 README（安装与验证步骤）

## 1. 基础能力

- [x] 实现日志工具（带统一前缀）
- [x] 实现 token 管理：
  - [x] `getAccessToken()`
  - [x] `getRefreshToken()`
  - [x] token 缺失错误提示
- [x] 实现 API 请求封装：
  - [x] 自动带 `x-jike-access-token`
  - [x] 401 自动刷新 token
  - [x] 重试一次

## 2. 数据拉取

- [x] 实现 `fetchPrimaryComments(targetId, targetType, loadMoreKey)`
- [x] 实现 `fetchPostDetail(postId, routeType)`（必要时补齐实际 `type`）
- [x] 实现缓存层（TTL + in-flight 去重）

## 3. DOM 注入

- [x] 识别动态卡片：
  - [x] 优先 `data-clickable-feedback="true"`
  - [x] 过滤非动态节点
- [x] 解析帖子元数据：
  - [x] 先尝试 React Fiber
  - [x] 再尝试 URL 路径兜底
- [x] 为卡片插入评论容器节点
- [x] 渲染评论条目 UI（作者、时间、文本、赞/回复计数）
- [x] 渲染空态/错误态/加载态

## 4. 自动加载与交互

- [x] `MutationObserver` 监听新卡片
- [x] `IntersectionObserver` 懒加载评论
- [x] “展开更多”按钮加载下一页
- [x] 防重复渲染与节点销毁恢复

## 5. 验证

- [x] JSON 语法与路径检查（manifest）
- [x] 简单静态检查（`node --check src/content.js`）
- [x] 人工验证步骤整理（需要用户配合安装）
