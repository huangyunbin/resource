# OKJike Inline Comments

一个 Chrome Manifest V3 插件：在即刻 Web 的 `following` 和个人主页页面为动态卡片自动展示评论预览。

## 功能

- 识别阅读流中的动态卡片并注入评论区
- 自动读取当前登录态 token（`JK_ACCESS_TOKEN`）
- 调用即刻评论接口加载评论
- 展示一级评论与二级回复（缩进区分层级，二级直接全量展示）
- 支持分页“展开更多评论”
- 接口 401 时自动尝试 refresh token
- 无评论时自动隐藏评论面板

## 目录

- `manifest.json`
- `src/content.js`
- `src/page-bridge.js`
- `src/styles.css`
- `docs/TECHNICAL_DESIGN.md`
- `docs/TODO.md`
- `docs/IMPLEMENTATION_RETROSPECTIVE.md`

## 本地安装

1. 打开 `chrome://extensions`
2. 开启右上角“开发者模式”
3. 点击“加载已解压的扩展程序”
4. 选择目录：`okjike-inline-comments`

## 使用方式

1. 保持你在即刻 Web 已登录状态
2. 访问 `https://web.okjike.com/following` 或 `https://web.okjike.com/u/{username}`
3. 滚动阅读流，动态卡片下方会自动出现“评论预览”
4. 点击“展开更多评论”可继续加载下一页

## 调试

- 页面控制台可查看前缀为 `[JKIC]` 的日志
- 若提示“未登录或登录态失效”，请刷新页面或重新登录即刻
- 若升级后仍有 `POST_META_NOT_FOUND`，先在扩展页点“重新加载”并刷新页面

## 已知限制

- 首版依赖当前页面结构与接口参数；站点更新后可能需调整选择器或字段
- 当前仅在 `/following` 与 `/u/{username}` 页面启用
