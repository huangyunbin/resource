(function () {
  if (window.__JKIC_PAGE_BRIDGE__) {
    return;
  }
  window.__JKIC_PAGE_BRIDGE__ = true;

  const CARD_SELECTOR = "div[data-clickable-feedback='true']";
  const TARGET_TYPES = {
    ORIGINAL_POST: "ORIGINAL_POST",
    REPOST: "REPOST",
    PERSONAL_UPDATE: "PERSONAL_UPDATE"
  };

  function isSupportedRoute() {
    const pathname = window.location.pathname;
    return pathname.startsWith("/following") || /^\/u\/[^/]+\/?$/.test(pathname);
  }

  function normalizeTargetType(value) {
    if (value === TARGET_TYPES.ORIGINAL_POST) return TARGET_TYPES.ORIGINAL_POST;
    if (value === TARGET_TYPES.REPOST) return TARGET_TYPES.REPOST;
    if (value === TARGET_TYPES.PERSONAL_UPDATE) return TARGET_TYPES.PERSONAL_UPDATE;
    if (value === "POST") return TARGET_TYPES.ORIGINAL_POST;
    return null;
  }

  function parsePostRoute(href) {
    if (!href) return null;
    let pathname = href;
    try {
      const url = new URL(href, window.location.origin);
      pathname = url.pathname;
    } catch (_) {
      return null;
    }

    const match = pathname.match(/^\/u\/([^/]+)\/(post|repost)\/([^/?#]+)/);
    if (!match) return null;

    return {
      id: match[3],
      targetType: match[2] === "repost" ? TARGET_TYPES.REPOST : TARGET_TYPES.ORIGINAL_POST,
      source: "link"
    };
  }

  function isPostData(data) {
    return !!(
      data &&
      typeof data === "object" &&
      typeof data.id === "string" &&
      typeof data.type === "string"
    );
  }

  function getReactInternalKeys(element) {
    const keys = Object.getOwnPropertyNames(element);
    return {
      fiberKey: keys.find((key) => key.startsWith("__reactFiber$")) || "",
      propsKey: keys.find((key) => key.startsWith("__reactProps$")) || ""
    };
  }

  function findPostDataInFiber(rootFiber) {
    if (!rootFiber) return null;
    const stack = [rootFiber];
    const seen = new Set();
    let steps = 0;

    while (stack.length && steps < 1500) {
      steps += 1;
      const fiber = stack.pop();
      if (!fiber || seen.has(fiber)) continue;
      seen.add(fiber);

      const data = fiber.memoizedProps && fiber.memoizedProps.data;
      if (isPostData(data)) {
        return data;
      }

      if (fiber.child) stack.push(fiber.child);
      if (fiber.sibling) stack.push(fiber.sibling);
      if (fiber.return) stack.push(fiber.return);
    }

    return null;
  }

  function extractMetaFromReact(card) {
    const { fiberKey, propsKey } = getReactInternalKeys(card);

    if (propsKey && card[propsKey] && isPostData(card[propsKey].data)) {
      const direct = card[propsKey].data;
      const targetType = normalizeTargetType(direct.type);
      if (targetType) {
        return { id: direct.id, targetType, source: "react.props" };
      }
    }

    if (fiberKey) {
      const postData = findPostDataInFiber(card[fiberKey]);
      if (postData) {
        const targetType = normalizeTargetType(postData.type);
        if (targetType) {
          return { id: postData.id, targetType, source: "react.fiber" };
        }
      }
    }

    return null;
  }

  function extractMetaFromLinks(card) {
    const anchors = card.querySelectorAll("a[href]");
    for (const anchor of anchors) {
      const parsed = parsePostRoute(anchor.getAttribute("href"));
      if (parsed) {
        return parsed;
      }
    }
    return null;
  }

  function resolveMeta(card) {
    return extractMetaFromReact(card) || extractMetaFromLinks(card);
  }

  function annotateCard(card) {
    if (!(card instanceof HTMLElement)) return;
    const meta = resolveMeta(card);
    if (!meta) return;
    card.dataset.jkicPostId = meta.id;
    card.dataset.jkicPostType = meta.targetType;
    card.dataset.jkicMetaSource = meta.source;
  }

  function scan(root) {
    if (!(root instanceof Document || root instanceof HTMLElement)) return;
    const cards = root.querySelectorAll(CARD_SELECTOR);
    cards.forEach((card) => annotateCard(card));
  }

  function boot() {
    scan(document);

    const mutationObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof HTMLElement)) continue;
          if (node.matches(CARD_SELECTOR)) {
            annotateCard(node);
            continue;
          }
          scan(node);
        }
      }
    });

    mutationObserver.observe(document.body, {
      childList: true,
      subtree: true
    });

    const timer = window.setInterval(() => {
      if (!isSupportedRoute()) {
        return;
      }
      scan(document);
    }, 1200);

    window.addEventListener("beforeunload", () => {
      mutationObserver.disconnect();
      window.clearInterval(timer);
    });
  }

  boot();
})();
