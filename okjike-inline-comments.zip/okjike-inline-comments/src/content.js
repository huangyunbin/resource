(function () {
  if (window.__JKIC_BOOTSTRAPPED__) {
    return;
  }
  window.__JKIC_BOOTSTRAPPED__ = true;

  const EXT_TAG = "[JKIC]";
  const API_BASE = "https://api.ruguoapp.com";
  const ACCESS_TOKEN_KEY = "JK_ACCESS_TOKEN";
  const REFRESH_TOKEN_KEY = "JK_REFRESH_TOKEN";

  const COMMENT_ORDER = "LIKES";
  const COMMENT_PAGE_SIZE = 20;
  const REPLY_PAGE_SIZE = 5;
  const PREVIEW_SIZE = 5;
  const CACHE_TTL_MS = 2 * 60 * 1000;

  const TARGET_TYPES = {
    ORIGINAL_POST: "ORIGINAL_POST",
    REPOST: "REPOST",
    PERSONAL_UPDATE: "PERSONAL_UPDATE"
  };

  const ROUTE_TO_TARGET_TYPE = {
    post: TARGET_TYPES.ORIGINAL_POST,
    repost: TARGET_TYPES.REPOST
  };

  const state = {
    isRunning: false,
    observers: {
      mutation: null,
      intersection: null
    },
    routeTimer: null,
    boundCards: new WeakSet(),
    panelByCard: new WeakMap(),
    panelStateByPanel: new WeakMap(),
    commentsCache: new Map(),
    repliesCache: new Map(),
    postTypeCache: new Map(),
    inFlight: new Map(),
    refreshPromise: null
  };

  function log(...args) {
    console.debug(EXT_TAG, ...args);
  }

  function warn(...args) {
    console.warn(EXT_TAG, ...args);
  }

  function injectPageBridge() {
    if (document.getElementById("jkic-page-bridge")) {
      return;
    }
    if (!window.chrome || !chrome.runtime || !chrome.runtime.getURL) {
      return;
    }

    const script = document.createElement("script");
    script.id = "jkic-page-bridge";
    script.src = chrome.runtime.getURL("src/page-bridge.js");
    script.async = false;
    script.onload = () => {
      script.remove();
    };
    script.onerror = () => {
      warn("page bridge inject failed");
    };
    (document.head || document.documentElement).appendChild(script);
  }

  function isSupportedRoute() {
    const pathname = window.location.pathname;
    return pathname.startsWith("/following") || /^\/u\/[^/]+\/?$/.test(pathname);
  }

  function getAccessToken() {
    const token = localStorage.getItem(ACCESS_TOKEN_KEY);
    return typeof token === "string" && token.trim() ? token.trim() : "";
  }

  function getRefreshToken() {
    const token = localStorage.getItem(REFRESH_TOKEN_KEY);
    return typeof token === "string" && token.trim() ? token.trim() : "";
  }

  function setTokens(tokens) {
    if (tokens.accessToken) {
      localStorage.setItem(ACCESS_TOKEN_KEY, tokens.accessToken);
    }
    if (tokens.refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refreshToken);
    }
  }

  async function safeJson(response) {
    const text = await response.text();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  async function refreshAccessToken() {
    if (state.refreshPromise) {
      return state.refreshPromise;
    }

    const refreshToken = getRefreshToken();
    if (!refreshToken) {
      return null;
    }

    state.refreshPromise = fetch(`${API_BASE}/app_auth_tokens.refresh`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-jike-refresh-token": refreshToken
      },
      credentials: "include",
      body: "{}"
    })
      .then(async (response) => {
        const payload = await safeJson(response);
        if (!response.ok || !payload) {
          return null;
        }

        const accessToken = payload["x-jike-access-token"];
        const nextRefreshToken = payload["x-jike-refresh-token"];
        if (!accessToken || !nextRefreshToken) {
          return null;
        }

        setTokens({ accessToken, refreshToken: nextRefreshToken });
        return accessToken;
      })
      .catch(() => null)
      .finally(() => {
        state.refreshPromise = null;
      });

    return state.refreshPromise;
  }

  async function apiRequest(path, options = {}) {
    const {
      method = "GET",
      params = null,
      body = null,
      retryOn401 = true
    } = options;

    const accessToken = getAccessToken();
    if (!accessToken) {
      throw new Error("MISSING_ACCESS_TOKEN");
    }

    const url = new URL(path, API_BASE);
    if (params) {
      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
          url.searchParams.set(key, String(value));
        }
      }
    }

    const response = await fetch(url.toString(), {
      method,
      headers: {
        "content-type": "application/json",
        "x-jike-access-token": accessToken
      },
      credentials: "include",
      body: method === "GET" ? undefined : JSON.stringify(body || {})
    });

    if (response.status === 401 && retryOn401) {
      const refreshed = await refreshAccessToken();
      if (refreshed) {
        return apiRequest(path, { method, params, body, retryOn401: false });
      }
      throw new Error("UNAUTHORIZED");
    }

    const payload = await safeJson(response);
    if (!response.ok) {
      const reason =
        (payload && (payload.error || payload.message || payload.toast)) ||
        `${response.status}`;
      throw new Error(`HTTP_${response.status}:${reason}`);
    }

    if (payload && payload.success === false) {
      throw new Error(payload.error || payload.message || "API_SUCCESS_FALSE");
    }

    return payload;
  }

  function cacheKey(targetId, targetType) {
    return `${targetType}:${targetId}:${COMMENT_ORDER}`;
  }

  function getFreshCache(targetId, targetType) {
    const key = cacheKey(targetId, targetType);
    const entry = state.commentsCache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.updatedAt > CACHE_TTL_MS) {
      state.commentsCache.delete(key);
      return null;
    }
    return entry;
  }

  function setCache(targetId, targetType, items, loadMoreKey) {
    const key = cacheKey(targetId, targetType);
    state.commentsCache.set(key, {
      items: Array.isArray(items) ? items.slice() : [],
      loadMoreKey: loadMoreKey === undefined ? null : loadMoreKey,
      updatedAt: Date.now()
    });
  }

  function replyCacheKey(primaryComment) {
    const targetType = primaryComment?.targetType || "";
    const targetId = primaryComment?.targetId || "";
    const threadId = primaryComment?.threadId || primaryComment?.id || "";
    const level = Number(primaryComment?.level || 1);
    return `${targetType}:${targetId}:${threadId}:${level}`;
  }

  function getFreshRepliesCache(primaryComment) {
    const key = replyCacheKey(primaryComment);
    const entry = state.repliesCache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.updatedAt > CACHE_TTL_MS) {
      state.repliesCache.delete(key);
      return null;
    }
    return entry;
  }

  function setRepliesCache(primaryComment, items) {
    const key = replyCacheKey(primaryComment);
    state.repliesCache.set(key, {
      items: Array.isArray(items) ? items.slice() : [],
      updatedAt: Date.now()
    });
  }

  function requestPrimaryComments(targetId, targetType, loadMoreKey) {
    const inFlightKey = `${targetType}:${targetId}:${String(loadMoreKey || "")}`;
    if (state.inFlight.has(inFlightKey)) {
      return state.inFlight.get(inFlightKey);
    }

    const promise = apiRequest("/1.0/comments/listPrimary", {
      method: "POST",
      body: {
        targetId,
        targetType,
        order: COMMENT_ORDER,
        limit: COMMENT_PAGE_SIZE,
        loadMoreKey: loadMoreKey === undefined ? null : loadMoreKey
      }
    })
      .then((payload) => ({
        items: Array.isArray(payload?.data) ? payload.data : [],
        loadMoreKey: payload?.loadMoreKey ?? null,
        targetType
      }))
      .finally(() => {
        state.inFlight.delete(inFlightKey);
      });

    state.inFlight.set(inFlightKey, promise);
    return promise;
  }

  function uniqueList(values) {
    const output = [];
    const seen = new Set();
    for (const value of values) {
      const key = `${value}`;
      if (value === undefined || value === null || key === "" || seen.has(key)) continue;
      seen.add(key);
      output.push(value);
    }
    return output;
  }

  function toSecondaryRequestParams(primaryComment, loadMoreKey, overrides) {
    const params = {
      targetType: overrides?.targetType ?? primaryComment.targetType,
      targetId: overrides?.targetId ?? primaryComment.targetId,
      primaryCommentId:
        overrides?.primaryCommentId ??
        primaryComment.threadId ??
        primaryComment.id,
      level:
        overrides?.level ??
        Math.max(1, Number(primaryComment.level || 1)),
      limit: overrides?.limit ?? REPLY_PAGE_SIZE
    };

    if (typeof overrides?.order === "string" && overrides.order) {
      params.order = overrides.order;
    }
    if (loadMoreKey !== undefined) {
      params.loadMoreKey = loadMoreKey;
    }

    return params;
  }

  function buildSecondaryRequestSeeds(primaryComment) {
    const basePrimaryCommentId = primaryComment.threadId || primaryComment.id;
    const baseLevel = Math.max(1, Number(primaryComment.level || 1));
    const primaryCommentIdCandidates = uniqueList([basePrimaryCommentId, primaryComment.id]);
    const levelCandidates = uniqueList([baseLevel, 1, baseLevel + 1, 2]);
    const targetTypeCandidates = uniqueList([
      primaryComment.targetType,
      TARGET_TYPES.ORIGINAL_POST,
      TARGET_TYPES.PERSONAL_UPDATE
    ]);
    const orderCandidates = [undefined, COMMENT_ORDER, "TIME"];

    const seeds = [];
    const seen = new Set();

    function pushSeed(overrides) {
      const params = toSecondaryRequestParams(primaryComment, undefined, overrides);
      const signature = [
        params.targetType,
        params.targetId,
        params.primaryCommentId,
        params.level,
        params.order || ""
      ].join("|");
      if (seen.has(signature)) return;
      seen.add(signature);
      seeds.push(params);
    }

    // Keep the first call aligned with the official web behavior.
    pushSeed({
      targetType: primaryComment.targetType,
      primaryCommentId: basePrimaryCommentId,
      level: baseLevel,
      order: undefined
    });

    for (const order of orderCandidates) {
      for (const targetType of targetTypeCandidates) {
        for (const primaryCommentId of primaryCommentIdCandidates) {
          for (const level of levelCandidates) {
            pushSeed({ targetType, primaryCommentId, level, order });
            if (seeds.length >= 14) {
              return seeds;
            }
          }
        }
      }
    }

    return seeds;
  }

  function requestSecondaryCommentsOnce(params, inFlightKey) {
    if (state.inFlight.has(inFlightKey)) {
      return state.inFlight.get(inFlightKey);
    }

    const promise = apiRequest("/1.0/comments/list", {
      method: "POST",
      body: params
    })
      .then((payload) => ({
        items: Array.isArray(payload?.data) ? payload.data : [],
        loadMoreKey: payload?.loadMoreKey ?? null
      }))
      .finally(() => {
        state.inFlight.delete(inFlightKey);
      });

    state.inFlight.set(inFlightKey, promise);
    return promise;
  }

  async function fetchSecondaryBySeed(primaryComment, seedParams, seedIndex) {
    const seenLoadMoreKeys = new Set();
    let loadMoreKey;
    let allItems = [];

    for (let round = 0; round < 8; round += 1) {
      const params = toSecondaryRequestParams(primaryComment, loadMoreKey, seedParams);
      const loadMoreToken = loadMoreKey ? JSON.stringify(loadMoreKey) : "first";
      const inFlightKey = `reply:${replyCacheKey(primaryComment)}:${seedIndex}:${round}:${loadMoreToken}`;
      const page = await requestSecondaryCommentsOnce(params, inFlightKey);
      allItems = mergeById(allItems, page.items);

      if (!page.loadMoreKey) {
        break;
      }

      const nextKey = JSON.stringify(page.loadMoreKey);
      if (seenLoadMoreKeys.has(nextKey)) {
        break;
      }
      seenLoadMoreKeys.add(nextKey);
      loadMoreKey = page.loadMoreKey;
    }

    return allItems;
  }

  async function getSecondaryComments(primaryComment) {
    const cached = getFreshRepliesCache(primaryComment);
    if (cached) {
      return cached.items.slice();
    }

    const expectedCount = Math.max(0, Number(primaryComment?.replyCount || 0));
    const seeds = buildSecondaryRequestSeeds(primaryComment);
    let allItems = [];
    let lastError = null;

    for (let index = 0; index < seeds.length; index += 1) {
      try {
        const items = await fetchSecondaryBySeed(primaryComment, seeds[index], index);
        allItems = mergeById(allItems, items);
      } catch (error) {
        lastError = error;
      }

      if (expectedCount > 0 && allItems.length >= expectedCount) {
        break;
      }
    }

    if (!allItems.length && lastError) {
      throw lastError;
    }

    setRepliesCache(primaryComment, allItems);
    return allItems.slice();
  }

  async function fetchCommentsWithFallback(meta, loadMoreKey) {
    const candidates = [meta.targetType];
    if (meta.targetType === TARGET_TYPES.ORIGINAL_POST) {
      candidates.push(TARGET_TYPES.PERSONAL_UPDATE);
    }

    let lastError = null;
    const tried = new Set();

    for (const targetType of candidates) {
      if (tried.has(targetType)) continue;
      tried.add(targetType);
      try {
        const page = await requestPrimaryComments(meta.id, targetType, loadMoreKey);
        return page;
      } catch (error) {
        lastError = error;
      }
    }

    throw lastError || new Error("FETCH_COMMENTS_FAILED");
  }

  async function fetchPostTargetType(postId, routeType) {
    const cacheId = `${routeType}:${postId}`;
    if (state.postTypeCache.has(cacheId)) {
      return state.postTypeCache.get(cacheId);
    }

    if (routeType === "repost") {
      state.postTypeCache.set(cacheId, TARGET_TYPES.REPOST);
      return TARGET_TYPES.REPOST;
    }

    if (routeType !== "post") {
      return null;
    }

    const payload = await apiRequest("/1.0/originalPosts/get", {
      method: "GET",
      params: { id: postId }
    });

    const post = payload?.data;
    const targetType = normalizeTargetType(post?.type) || TARGET_TYPES.ORIGINAL_POST;
    state.postTypeCache.set(cacheId, targetType);
    return targetType;
  }

  function normalizeTargetType(value) {
    if (value === TARGET_TYPES.ORIGINAL_POST) return TARGET_TYPES.ORIGINAL_POST;
    if (value === TARGET_TYPES.REPOST) return TARGET_TYPES.REPOST;
    if (value === TARGET_TYPES.PERSONAL_UPDATE) return TARGET_TYPES.PERSONAL_UPDATE;
    if (value === "POST") return TARGET_TYPES.ORIGINAL_POST;
    return null;
  }

  function extractMetaFromDataset(card) {
    const id = card.dataset.jkicPostId || "";
    const type = normalizeTargetType(card.dataset.jkicPostType || "");
    if (!id || !type) return null;
    return {
      id,
      targetType: type,
      source: "dataset"
    };
  }

  function parsePostRoute(href) {
    if (!href) return null;
    let pathname = href;
    try {
      const url = new URL(href, window.location.origin);
      pathname = url.pathname;
    } catch (_) {
      return null;
    }

    const match = pathname.match(/^\/u\/([^/]+)\/(post|repost)\/([^/?#]+)/);
    if (!match) return null;

    return {
      username: match[1],
      routeType: match[2],
      id: match[3]
    };
  }

  function isPostData(data) {
    return !!(
      data &&
      typeof data === "object" &&
      typeof data.id === "string" &&
      typeof data.type === "string"
    );
  }

  function getReactInternalKeys(element) {
    const keys = Object.getOwnPropertyNames(element);
    return {
      fiberKey: keys.find((key) => key.startsWith("__reactFiber$")) || "",
      propsKey: keys.find((key) => key.startsWith("__reactProps$")) || ""
    };
  }

  function findPostDataInFiber(rootFiber) {
    if (!rootFiber) return null;
    const stack = [rootFiber];
    const seen = new Set();
    let steps = 0;

    while (stack.length && steps < 500) {
      steps += 1;
      const fiber = stack.pop();
      if (!fiber || seen.has(fiber)) continue;
      seen.add(fiber);

      const data = fiber.memoizedProps && fiber.memoizedProps.data;
      if (isPostData(data)) {
        return data;
      }

      if (fiber.child) stack.push(fiber.child);
      if (fiber.sibling) stack.push(fiber.sibling);
      if (fiber.return) stack.push(fiber.return);
    }

    return null;
  }

  function extractMetaFromFiber(card) {
    const { fiberKey, propsKey } = getReactInternalKeys(card);

    if (propsKey && card[propsKey] && isPostData(card[propsKey].data)) {
      const direct = card[propsKey].data;
      const targetType = normalizeTargetType(direct.type);
      if (targetType) {
        return { id: direct.id, targetType, source: "fiber.props" };
      }
    }

    if (fiberKey) {
      const postData = findPostDataInFiber(card[fiberKey]);
      if (postData) {
        const targetType = normalizeTargetType(postData.type);
        if (targetType) {
          return { id: postData.id, targetType, source: "fiber.tree" };
        }
      }
    }

    return null;
  }

  function extractMetaFromLinks(card) {
    const anchors = card.querySelectorAll("a[href]");
    for (const anchor of anchors) {
      const parsed = parsePostRoute(anchor.getAttribute("href"));
      if (!parsed) continue;
      const targetType = ROUTE_TO_TARGET_TYPE[parsed.routeType];
      if (!targetType) continue;
      return {
        id: parsed.id,
        targetType,
        routeType: parsed.routeType,
        source: "link"
      };
    }
    return null;
  }

  function resolveCardMeta(card) {
    return extractMetaFromDataset(card) || extractMetaFromFiber(card) || extractMetaFromLinks(card);
  }

  function isProfileLinkHref(href) {
    if (!href) return false;
    let pathname = href;
    try {
      pathname = new URL(href, window.location.origin).pathname;
    } catch (_) {
      return false;
    }
    return /^\/u\/[^/?#]+$/.test(pathname);
  }

  function looksLikePostCard(card) {
    if (!(card instanceof HTMLElement)) return false;
    if (!card.matches("div[data-clickable-feedback='true']")) return false;
    if (card.dataset.jkicPostId && card.dataset.jkicPostType) return true;
    const anchors = card.querySelectorAll("a[href]");
    for (const anchor of anchors) {
      if (isProfileLinkHref(anchor.getAttribute("href"))) {
        return true;
      }
    }
    return false;
  }

  function ensureCardPanel(card) {
    let panel = state.panelByCard.get(card);
    if (panel) return panel;

    panel = document.createElement("section");
    panel.className = "jkic-panel";
    panel.style.display = "none";
    panel.innerHTML =
      '<div class="jkic-header">评论预览</div>' +
      '<div class="jkic-body jkic-text-muted">等待加载...</div>';

    panel.addEventListener("click", onPanelClick);
    panel.addEventListener("mousedown", stopCardNavigation);
    panel.addEventListener("mouseup", stopCardNavigation);
    panel.addEventListener("touchstart", stopCardNavigation, { passive: true });

    const container = card.firstElementChild;
    const content = container && container.children ? container.children[1] : null;
    if (content instanceof HTMLElement) {
      content.appendChild(panel);
    } else {
      card.appendChild(panel);
    }

    state.panelByCard.set(card, panel);
    state.panelStateByPanel.set(panel, {
      loaded: false,
      loading: false,
      loadingMore: false,
      loadMoreKey: null,
      items: [],
      visibleCount: PREVIEW_SIZE,
      metaRetryCount: 0,
      error: "",
      meta: null
    });

    return panel;
  }

  function stopCardNavigation(event) {
    event.stopPropagation();
  }

  function onPanelClick(event) {
    event.stopPropagation();
    const panel = event.currentTarget;
    if (!(panel instanceof HTMLElement)) return;
    const actionButton = event.target instanceof Element
      ? event.target.closest("button[data-jkic-action]")
      : null;
    if (!actionButton) return;

    const action = actionButton.getAttribute("data-jkic-action") || "";
    if (action === "more") {
      void loadMoreComments(panel);
    }
  }

  function escapeHtml(text) {
    return String(text || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function pickAvatar(user) {
    if (!user || typeof user !== "object") return "";
    const avatarImage = user.avatarImage || {};
    return (
      avatarImage.thumbnailUrl ||
      avatarImage.smallPicUrl ||
      avatarImage.picUrl ||
      ""
    );
  }

  function toFriendlyError(error) {
    const message = error instanceof Error ? error.message : String(error || "");
    if (message.includes("MISSING_ACCESS_TOKEN") || message.includes("UNAUTHORIZED")) {
      return "未登录或登录态失效";
    }
    if (message.includes("429")) {
      return "请求过于频繁，请稍后再试";
    }
    return "评论加载失败";
  }

  function commentItemHtml(comment) {
    const user = comment?.user || {};
    const screenName = escapeHtml(user.screenName || user.username || "匿名用户");
    const content = escapeHtml(comment?.content || "");
    const avatar = escapeHtml(pickAvatar(user));
    const replies = Array.isArray(comment?._jkicReplyState?.items)
      ? comment._jkicReplyState.items
      : Array.isArray(comment?.hotReplies)
        ? comment.hotReplies
        : [];

    return (
      '<article class="jkic-comment">' +
      `<img class="jkic-avatar" src="${avatar}" alt="" referrerpolicy="no-referrer" loading="lazy" />` +
      '<div class="jkic-main">' +
      `<div class="jkic-meta"><span class="jkic-name">${screenName}</span></div>` +
      `<div class="jkic-content">${content || "（无文本）"}</div>` +
      repliesHtml(replies) +
      "</div>" +
      "</article>"
    );
  }

  function replyItemHtml(comment) {
    const user = comment?.user || {};
    const screenName = escapeHtml(user.screenName || user.username || "匿名用户");
    const content = escapeHtml(comment?.content || "");
    const avatar = escapeHtml(pickAvatar(user));
    return (
      '<article class="jkic-reply">' +
      `<img class="jkic-reply-avatar" src="${avatar}" alt="" referrerpolicy="no-referrer" loading="lazy" />` +
      '<div class="jkic-reply-main">' +
      `<div class="jkic-reply-meta"><span class="jkic-reply-name">${screenName}</span></div>` +
      `<div class="jkic-reply-content">${content || "（无文本）"}</div>` +
      "</div>" +
      "</article>"
    );
  }

  function repliesHtml(replies) {
    if (!Array.isArray(replies) || replies.length === 0) {
      return "";
    }

    return (
      '<div class="jkic-replies">' +
      replies.map((reply) => replyItemHtml(reply)).join("") +
      "</div>"
    );
  }

  function ensureReplyState(comment) {
    if (!comment._jkicReplyState) {
      comment._jkicReplyState = {
        items: [],
        loaded: false,
        totalCount: Math.max(0, Number(comment?.replyCount || 0)),
        source: "unknown"
      };
    }
    comment._jkicReplyState.totalCount = Math.max(
      Number(comment._jkicReplyState.totalCount || 0),
      Number(comment?.replyCount || 0)
    );
    return comment._jkicReplyState;
  }

  async function enrichRepliesForVisibleComments(panelState) {
    const visiblePrimary = panelState.items.slice(
      0,
      Math.min(panelState.visibleCount || PREVIEW_SIZE, panelState.items.length)
    );

    const tasks = visiblePrimary
      .filter((comment) => {
        const replyState = ensureReplyState(comment);
        return !replyState.loaded;
      })
      .map(async (comment) => {
        const replyState = ensureReplyState(comment);

        if (!Number(comment?.replyCount || 0)) {
          replyState.items = [];
          replyState.loaded = true;
          replyState.source = "none";
          return;
        }

        try {
          const items = await getSecondaryComments(comment);
          const hotReplies = Array.isArray(comment.hotReplies) ? comment.hotReplies : [];
          replyState.items = mergeById(hotReplies, items);
          replyState.loaded = true;
          replyState.source = "api";
        } catch (_) {
          replyState.items = Array.isArray(comment.hotReplies) ? comment.hotReplies : [];
          replyState.loaded = true;
          replyState.source = "fallback";
        }
      });

    if (tasks.length) {
      await Promise.all(tasks);
    }
  }

  function renderPanel(panel) {
    const panelState = state.panelStateByPanel.get(panel);
    if (!panelState) return;

    const comments = panelState.items || [];
    if (!panelState.loading && !panelState.error && panelState.loaded && comments.length === 0) {
      panel.style.display = "none";
      return;
    }

    panel.style.display = "";
    const visibleCount = Math.max(
      0,
      Math.min(Number(panelState.visibleCount || PREVIEW_SIZE), comments.length)
    );
    const renderedItems = comments.slice(0, visibleCount);
    let bodyHtml = "";

    if (panelState.loading && comments.length === 0) {
      bodyHtml = '<div class="jkic-body jkic-text-muted">正在加载评论...</div>';
    } else if (panelState.error && comments.length === 0) {
      bodyHtml = `<div class="jkic-body jkic-error">${escapeHtml(panelState.error)}</div>`;
    } else if (comments.length === 0) {
      bodyHtml = '<div class="jkic-body jkic-text-muted">暂无评论</div>';
    } else {
      bodyHtml =
        '<div class="jkic-list">' +
        renderedItems.map((comment) => commentItemHtml(comment)).join("") +
        "</div>";
    }

    const extraErrorHtml =
      panelState.error && comments.length > 0
        ? `<div class="jkic-inline-error">${escapeHtml(panelState.error)}</div>`
        : "";

    const canShowMoreLoaded = visibleCount < comments.length;
    const canLoadMore = !!panelState.loadMoreKey;
    const moreButtonHtml = canShowMoreLoaded || canLoadMore
      ? `<button class="jkic-more" data-jkic-action="more" ${
          panelState.loadingMore ? "disabled" : ""
        }>${
          panelState.loadingMore
            ? "加载中..."
            : canShowMoreLoaded
              ? "显示更多"
              : "展开更多评论"
        }</button>`
      : "";

    panel.innerHTML =
      '<div class="jkic-header">评论预览</div>' +
      bodyHtml +
      extraErrorHtml +
      moreButtonHtml;
  }

  function mergeById(existing, nextPage) {
    const output = [];
    const seen = new Set();
    for (const item of existing.concat(nextPage)) {
      const id = item && item.id;
      if (!id || seen.has(id)) continue;
      seen.add(id);
      output.push(item);
    }
    return output;
  }

  async function loadCardComments(card) {
    const panel = state.panelByCard.get(card) || ensureCardPanel(card);
    const panelState = state.panelStateByPanel.get(panel);
    if (!panelState || panelState.loaded || panelState.loading) return;

    panelState.loading = true;
    panelState.error = "";
    renderPanel(panel);

    try {
      const meta = resolveCardMeta(card);
      if (!meta) {
        panelState.metaRetryCount = (panelState.metaRetryCount || 0) + 1;
        if (panelState.metaRetryCount <= 5) {
          panelState.loading = false;
          panelState.error = "正在识别动态信息...";
          renderPanel(panel);
          window.setTimeout(() => {
            void loadCardComments(card);
          }, 500);
          return;
        }
        throw new Error("POST_META_NOT_FOUND");
      }
      panelState.metaRetryCount = 0;
      if (meta.source === "link" && meta.routeType) {
        try {
          const patchedType = await fetchPostTargetType(meta.id, meta.routeType);
          if (patchedType) {
            meta.targetType = patchedType;
          }
        } catch (error) {
          warn("fetchPostTargetType failed", error);
        }
      }
      panelState.meta = meta;

      const cacheEntry = getFreshCache(meta.id, meta.targetType);
      if (cacheEntry) {
        panelState.items = cacheEntry.items.slice();
        panelState.visibleCount = Math.min(PREVIEW_SIZE, panelState.items.length);
        panelState.loadMoreKey = cacheEntry.loadMoreKey;
        panelState.loaded = true;
        await enrichRepliesForVisibleComments(panelState);
        return;
      }

      const page = await fetchCommentsWithFallback(meta, null);
      panelState.items = page.items;
      panelState.visibleCount = Math.min(PREVIEW_SIZE, panelState.items.length);
      panelState.loadMoreKey = page.loadMoreKey;
      panelState.loaded = true;
      panelState.meta.targetType = page.targetType;

      await enrichRepliesForVisibleComments(panelState);

      setCache(meta.id, page.targetType, panelState.items, panelState.loadMoreKey);
    } catch (error) {
      panelState.error = toFriendlyError(error);
      warn("loadCardComments failed", error);
    } finally {
      panelState.loading = false;
      renderPanel(panel);
    }
  }

  async function loadMoreComments(panel) {
    const panelState = state.panelStateByPanel.get(panel);
    if (!panelState || !panelState.meta) return;
    if (panelState.visibleCount < panelState.items.length) {
      panelState.visibleCount = Math.min(
        panelState.visibleCount + PREVIEW_SIZE,
        panelState.items.length
      );
      await enrichRepliesForVisibleComments(panelState);
      renderPanel(panel);
      return;
    }
    if (panelState.loadingMore || !panelState.loadMoreKey) return;

    panelState.loadingMore = true;
    panelState.error = "";
    renderPanel(panel);

    try {
      const page = await fetchCommentsWithFallback(panelState.meta, panelState.loadMoreKey);
      panelState.items = mergeById(panelState.items, page.items);
      panelState.visibleCount = Math.min(
        panelState.visibleCount + PREVIEW_SIZE,
        panelState.items.length
      );
      panelState.loadMoreKey = page.loadMoreKey;
      panelState.meta.targetType = page.targetType;

      await enrichRepliesForVisibleComments(panelState);

      setCache(
        panelState.meta.id,
        panelState.meta.targetType,
        panelState.items,
        panelState.loadMoreKey
      );
    } catch (error) {
      panelState.error = toFriendlyError(error);
      warn("loadMoreComments failed", error);
    } finally {
      panelState.loadingMore = false;
      renderPanel(panel);
    }
  }

  function isCardElement(node) {
    return (
      node instanceof HTMLElement &&
      node.matches("div[data-clickable-feedback='true']")
    );
  }

  function registerCard(card) {
    if (!(card instanceof HTMLElement)) return;
    if (!looksLikePostCard(card)) return;
    if (state.boundCards.has(card)) return;
    state.boundCards.add(card);

    ensureCardPanel(card);
    if (state.observers.intersection) {
      state.observers.intersection.observe(card);
    }
  }

  function scanCards(root) {
    if (!(root instanceof HTMLElement || root instanceof Document)) return;
    const cards = root.querySelectorAll("div[data-clickable-feedback='true']");
    cards.forEach((card) => registerCard(card));
  }

  function createObservers() {
    const intersection = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const card = entry.target;
          if (!(card instanceof HTMLElement)) continue;
          void loadCardComments(card);
        }
      },
      {
        root: null,
        threshold: 0.35
      }
    );

    const mutation = new MutationObserver((mutations) => {
      for (const mutationItem of mutations) {
        for (const node of mutationItem.addedNodes) {
          if (!(node instanceof HTMLElement)) continue;
          if (isCardElement(node)) {
            registerCard(node);
            continue;
          }
          scanCards(node);
        }
      }
    });

    mutation.observe(document.body, {
      childList: true,
      subtree: true
    });

    state.observers.intersection = intersection;
    state.observers.mutation = mutation;
  }

  function disconnectObservers() {
    if (state.observers.intersection) {
      state.observers.intersection.disconnect();
      state.observers.intersection = null;
    }
    if (state.observers.mutation) {
      state.observers.mutation.disconnect();
      state.observers.mutation = null;
    }
  }

  function clearPanels() {
    document.querySelectorAll(".jkic-panel").forEach((node) => node.remove());
  }

  function resetRuntimeState() {
    state.boundCards = new WeakSet();
    state.panelByCard = new WeakMap();
    state.panelStateByPanel = new WeakMap();
  }

  function startForFollowingRoute() {
    if (state.isRunning) return;
    state.isRunning = true;

    createObservers();
    scanCards(document);
    log("inline comments enabled");
  }

  function stopForOtherRoutes() {
    if (!state.isRunning) return;
    state.isRunning = false;

    disconnectObservers();
    clearPanels();
    resetRuntimeState();
    log("inline comments disabled for current route");
  }

  function checkRoute() {
    if (isSupportedRoute()) {
      startForFollowingRoute();
    } else {
      stopForOtherRoutes();
    }
  }

  function boot() {
    injectPageBridge();
    checkRoute();
    state.routeTimer = window.setInterval(checkRoute, 1000);
  }

  boot();
})();
