# 开发任务清单

## 阶段一：基础框架

- [ ] **Task 1**: 创建 manifest.json
  - 配置插件基本信息（名称、版本、描述）
  - 声明权限：activeTab, downloads
  - 声明 host_permissions：syndication API 域名
  - 配置 popup 和 background service worker

- [ ] **Task 2**: 创建图标文件
  - 生成 icon16.png、icon48.png、icon128.png
  - 简单的下载箭头图标即可

## 阶段二：核心逻辑

- [ ] **Task 3**: 创建 background.js
  - 实现 `extractTweetId(url)` 函数：从 URL 提取推文 ID
  - 实现 `fetchVideoUrl(tweetId)` 函数：调用 syndication API
  - 实现 `getBestVideoUrl(data)` 函数：解析数据，选择最高画质
  - 实现 `downloadVideo(url, tweetId)` 函数：触发下载
  - 监听来自 popup 的消息，执行下载流程

- [ ] **Task 4**: 创建 popup.html
  - 基础 HTML 结构
  - 下载按钮
  - 状态显示区域

- [ ] **Task 5**: 创建 popup.css
  - 简洁的样式
  - 按钮样式
  - 状态文字样式

- [ ] **Task 6**: 创建 popup.js
  - 获取当前 tab URL
  - 点击按钮时发送消息给 background
  - 显示状态反馈（检测中、成功、错误）

## 阶段三：测试验证

- [ ] **Task 7**: 本地加载插件测试
  - Chrome 加载未打包扩展
  - 测试正常推文视频下载
  - 测试错误场景（非推文页、无视频推文）

## 阶段四：优化完善

- [ ] **Task 8**: 错误处理优化
  - 完善各种错误提示
  - 网络超时处理

- [ ] **Task 9**: 用户体验优化
  - 下载中状态显示
  - 下载完成提示

---

## 执行顺序

```
Task 1 → Task 2 → Task 3 → Task 4 → Task 5 → Task 6 → Task 7 → Task 8 → Task 9
```

先完成 Task 1-6 即可得到可运行的最小版本。
