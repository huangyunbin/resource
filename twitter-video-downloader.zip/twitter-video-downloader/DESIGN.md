# Twitter 视频下载插件 - 技术方案 (v1.1.0)

## 项目概述

一个强大且稳健的 Chrome 浏览器插件，用于下载 Twitter/X 上的视频。
**v1.1.0 重大更新**：采用了全新的“GraphQL 拦截 + 模拟”架构，完美支持普通视频、**敏感内容/年龄限制视频**、以及**广告/卡片类 (Card) 视频**。

## 设计原则

- **无感拦截**：自动捕获浏览器发出的真实 API 请求，无需手动更新 Token。
- **全量解析**：递归扫描 JSON 响应，确保能挖掘出隐藏在任何深度的视频链接。
- **用户鉴权**：复用用户当前的登录状态 (Cookie)，无视敏感内容限制。

---

## 核心技术架构演进 (History & Reasoning)

在开发过程中，为了应对 Twitter 复杂的反爬策略，我们经历了以下几个阶段的尝试：

### ❌ 方案一：公共 API (Syndication API)
- **原理**：调用 `cdn.syndication.twimg.com/tweet-result`。
- **失败原因**：该 API 是公开的，**不支持敏感内容 (NSFW)**。对于受限视频，它直接返回 `TweetTombstone` 错误。

### ❌ 方案二：HTML 源码正则提取
- **原理**：`fetch(window.location.href)` 获取源码，用正则搜 `video/mp4`。
- **失败原因**：Twitter 是 SPA (单页应用)，HTML 源码里往往只有骨架，没有数据。数据是异步加载的。

### ❌ 方案三：DOM / Performance 扫描
- **原理**：扫描页面上的 `<video>` 标签或 `performance.getEntries()`。
- **失败原因**：
    1.  Twitter 网页端播放的是 **HLS (.m3u8)** 流，由数百个切片组成，插件无法直接下载合并。
    2.  虽然播放的是 m3u8，但后台 API 其实提供了 mp4 源文件，只是 DOM 里找不到。

### ✅ 方案四 (当前方案)：GraphQL 流量监听 + 模拟请求
- **原理**：
    1.  **监听 (Sniffing)**：在后台监听浏览器发出的真实 GraphQL 请求 (`TweetDetail`)。
    2.  **捕获 (Capture)**：记录下请求的 URL 模板 (包含了最新的 Query ID 和 Features)。
    3.  **重放 (Replay)**：当用户点击下载时，使用捕获的模板，将 `focalTweetId` 替换为目标 ID，带上用户的 Cookie 重新发起请求。
    4.  **解析 (Deep Parse)**：使用递归算法全量扫描返回的 JSON，提取 mp4 链接。

---

## 当前文件结构

```
twitter-video-downloader/
├── manifest.json        # 权限配置 (webRequest, cookies, scripting, downloads)
├── background.js        # 核心逻辑：监听器、请求模拟、递归解析
├── icons/               # 图标资源
└── DESIGN.md            # 本文档
```

## 核心实现细节

### 1. 动态 API 模板捕获 (Dynamic Template Capture)

Twitter 的 GraphQL API URL 包含随机生成的 Query ID (例如 `s-CkpJjp...`)，且经常变动。我们不再硬编码它。

```javascript
// 监听器：守株待兔
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        if (details.url.includes("/graphql/")) {
            // 记录下这个 URL，它就是通往数据的钥匙
            capturedRequests.push(details.url); 
        }
    },
    { urls: ["*://x.com/i/api/graphql/*"] }
);
```

### 2. 递归解析算法 (The "Omni-Parser")

为了解决 Card Video (跳转链接视频) 藏得太深的问题，我们实现了一个无视结构的递归解析器。

```javascript
function extractVideoUrl(json) {
    const mp4s = [];
    
    function scan(obj) {
        // 1. 也是最常见的情况：发现 variants 数组
        if (isVariantsArray(obj)) {
            mp4s.push(extractMp4(obj));
        }
        
        // 2. 特殊情况：Card JSON 字符串 (字符串里套 JSON)
        if (obj.key === "unified_card") {
            const nested = JSON.parse(obj.value.string_value);
            scan(nested); // 递归进入字符串内部
        }

        // 3. 继续向下挖掘
        for (let child of Object.values(obj)) {
            scan(child);
        }
    }
    
    scan(json);
    
    // 4. 保底策略：如果递归没找到，把 JSON 转成字符串用正则暴力搜
    if (mp4s.length === 0) {
        return regexSearch(JSON.stringify(json));
    }
}
```

### 3. 用户交互流程

1.  用户点击插件图标。
2.  插件检查 `capturedRequests` 是否为空。
    -   **空**：提示用户“请刷新页面”（为了触发流量以供捕获）。
    -   **非空**：提取最新的 URL 模板。
3.  插件使用 `chrome.cookies` 获取 `ct0` (CSRF Token)。
4.  插件发起 `fetch` 请求。
5.  解析 JSON 拿到 mp4 地址。
6.  `chrome.downloads` 下载文件。

---

## 权限说明

- `webRequest`：用于监听 `onBeforeRequest`，捕获 API URL。
- `cookies`：用于读取 `ct0`，以便伪装成登录用户。
- `scripting`：仅用于在页面上执行 `alert()` 提示用户刷新。
- `downloads`：下载文件。
- `activeTab`：确保在当前页面有操作权限。

---

## 待优化项

- 目前依赖用户“刷新页面”来初次捕获模板。如果能持久化存储模板到 `chrome.storage`，体验会更好（不需要每次重启浏览器都刷新）。
- 增加对 GIF 的专门支持（目前虽然能下，但会被当成 mp4）。
