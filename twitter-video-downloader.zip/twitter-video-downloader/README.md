# Twitter Video Downloader

一个简洁的 Chrome 浏览器插件,用于一键下载 Twitter/X 上的视频。

## 功能特点

- 🚀 一键下载 Twitter/X 视频
- 🎯 自动选择最高画质
- 💡 简洁易用的界面
- 🔒 无需 Twitter 账号或 API Token

## 安装方法

1. 打开 Chrome 浏览器
2. 访问 `chrome://extensions/`
3. 开启右上角的"开发者模式"
4. 点击"加载已解压的扩展程序"
5. 选择本项目文件夹
6. 安装完成!

## 使用方法

1. 打开任意 Twitter/X 推文详情页(包含视频的推文)
2. 点击浏览器工具栏中的插件图标
3. 视频自动下载到浏览器默认下载目录

## 项目结构

```
twitter-video-downloader/
├── manifest.json        # 插件配置文件
├── background.js        # 后台服务脚本(API调用、下载逻辑)
├── icons/               # 插件图标
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── DESIGN.md            # 技术设计文档
├── TASKS.md             # 任务清单
└── README.md            # 使用说明
```

## 技术实现

- 使用 Chrome Extension Manifest V3
- 调用 Twitter Syndication API 获取视频数据
- 自动选择最高 bitrate 的 mp4 视频
- 使用 `chrome.downloads` API 触发下载

## 注意事项

- 仅支持公开推文的视频下载
- 需要在推文详情页使用(URL 包含 `/status/`)
- 支持 twitter.com 和 x.com 域名
- 下载的视频会以 `twitter_{推文ID}.mp4` 命名

## 常见问题

**Q: 提示"该推文没有视频"?**  
A: 请确保该推文确实包含视频内容(而非图片或GIF)

**Q: 下载失败怎么办?**  
A: 请检查网络连接,或尝试刷新页面后重试

**Q: 可以下载私密推文的视频吗?**  
A: 不可以,插件仅支持公开推文

## 开源协议

MIT License
