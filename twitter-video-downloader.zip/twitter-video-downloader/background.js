// -----------------------------------------------------------------------------
// 全局变量：用于存储最近捕获的 GraphQL 请求信息 (API 模板)
// -----------------------------------------------------------------------------
let capturedRequests = [];

// -----------------------------------------------------------------------------
// 1. 监听器：捕获 Twitter 前端的真实 GraphQL 请求
//    这是为了动态获取最新的 Query ID 和 Features 参数，防止 API 升级导致失效
// -----------------------------------------------------------------------------
chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
        if (details.method === "GET" && details.url.includes("/graphql/")) {
            // 只保留最近的 20 个请求，防止内存泄漏
            if (capturedRequests.length > 20) capturedRequests.shift();
            capturedRequests.push({ url: details.url, timeStamp: Date.now() });
        }
    },
    { urls: ["*://x.com/i/api/graphql/*", "*://twitter.com/i/api/graphql/*"] }
);

// -----------------------------------------------------------------------------
// 2. 辅助函数
// -----------------------------------------------------------------------------

// 获取 Twitter 的鉴权 Cookie (ct0)
function getCookie(name) {
    return new Promise(resolve => {
        chrome.cookies.get({ url: "https://x.com", name: name }, (cookie) => {
            resolve(cookie ? cookie.value : null);
        });
    });
}

// 在捕获的请求列表中，寻找最适合作为模板的 URL
function findBestMatchingUrl() {
    // 倒序查找，优先使用最新的
    for (let i = capturedRequests.length - 1; i >= 0; i--) {
        const req = capturedRequests[i];
        // TweetDetail 是最理想的模板，TweetResult 也可以
        if (req.url.includes("TweetDetail") || req.url.includes("TweetResult")) {
            return req.url;
        }
    }
    // 如果没有完美的匹配，只要是 graphql 都有可能用（只要它带了 variables）
    return capturedRequests.length > 0 ? capturedRequests[capturedRequests.length - 1].url : null;
}

// -----------------------------------------------------------------------------
// 3. 核心网络请求：伪装成浏览器发起 GraphQL 查询
// -----------------------------------------------------------------------------
async function fetchTweetData(tweetId) {
    try {
        const csrfToken = await getCookie("ct0");
        if (!csrfToken) {
            console.error("无法获取登录状态 (ct0 cookie丢失)");
            return null;
        }

        const targetUrl = findBestMatchingUrl();
        if (!targetUrl) return "REFRESH_REQUIRED";

        // 解析并重建 URL
        const urlObj = new URL(targetUrl);
        const params = new URLSearchParams(urlObj.search);
        
        const variablesStr = params.get("variables");
        if (!variablesStr) return "REFRESH_REQUIRED";

        // 替换 ID 为当前目标 Tweet 的 ID
        let variables = JSON.parse(variablesStr);
        variables.focalTweetId = tweetId; 
        variables.tweetId = tweetId;
        variables.rest_id = tweetId;

        params.set("variables", JSON.stringify(variables));
        urlObj.search = params.toString();
        
        // Twitter Web Client 固定使用的公钥
        const bearerToken = "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";

        const response = await fetch(urlObj.toString(), {
            headers: {
                "authorization": bearerToken,
                "x-csrf-token": csrfToken,
                "x-twitter-active-user": "yes",
                "x-twitter-client-language": "en"
            }
        });

        if (!response.ok) return null;
        return await response.json();
    } catch (e) {
        console.error("API 请求失败:", e);
        return null;
    }
}

// -----------------------------------------------------------------------------
// 4. 解析器：深度递归 + 正则扫描
//    (既支持普通视频，也支持 Card/Unified_Card 这种深层嵌套的视频)
// -----------------------------------------------------------------------------
function extractVideoUrl(json) {
    const mp4s = [];
    const visited = new Set(); // 防止循环引用

    // 递归遍历 JSON 树
    function scan(obj) {
        if (!obj || typeof obj !== 'object' || visited.has(obj)) return;
        visited.add(obj);

        // A. 检查当前节点是否是 Variants 数组 (视频源列表)
        if (Array.isArray(obj) && obj.length > 0) {
            // 简单的特征检测：如果有 content_type 和 url，那它大概率是 variant
            const potentialVariant = obj[0];
            if (potentialVariant && potentialVariant.content_type && potentialVariant.url) {
                obj.forEach(v => {
                    if (v.content_type === "video/mp4") {
                        mp4s.push({ bitrate: v.bitrate || 0, url: v.url });
                    }
                });
            }
        }

        // B. 特殊处理：Unified Card (嵌套的 JSON 字符串)
        if (obj.key === "unified_card" && obj.value && obj.value.string_value) {
            try {
                const nestedJson = JSON.parse(obj.value.string_value);
                scan(nestedJson); // 递归进入解开后的对象
            } catch(e) {}
        }

        // C. 继续递归子属性
        // 优先遍历 array，再遍历 object values
        if (Array.isArray(obj)) {
            obj.forEach(scan);
        } else {
            Object.values(obj).forEach(scan);
        }
    }

    // 启动扫描
    scan(json);

    // D. 保底策略：如果递归没找到，直接把 JSON 转字符串用正则暴力搜
    // 这能解决某些我们漏掉的奇葩结构
    if (mp4s.length === 0) {
        const jsonStr = JSON.stringify(json);
        // 匹配所有 video.twimg.com 域名的 mp4 链接
        const regex = /https:\/\/video\.twimg\.com\/[^\"]+?\.mp4/g;
        const matches = jsonStr.match(regex);
        if (matches) {
            matches.forEach(url => {
                // 清理转义字符
                const cleanUrl = url.replace(/\\/g, '');
                mp4s.push({ bitrate: 0, url: cleanUrl });
            });
        }
    }

    if (mp4s.length === 0) return null;

    // 去重
    const uniqueMp4s = Array.from(new Map(mp4s.map(item => [item.url, item])).values());
    // 按码率降序排列，取最高画质
    uniqueMp4s.sort((a, b) => b.bitrate - a.bitrate);

    return uniqueMp4s[0].url;
}

// -----------------------------------------------------------------------------
// 5. 主入口
// -----------------------------------------------------------------------------
async function handleDownload(tab) {
    // 检查 URL 格式
    const match = tab.url.match(/(?:twitter\.com|x\.com)\/\w+\/status\/(\d+)/);
    if (!match) return; // 不是推文详情页
    const tweetId = match[1];

    // 检查是否已捕获模板
    if (capturedRequests.length === 0) {
        showAlert(tab.id, "插件刚启动，尚未捕获 API 模板。\n\n请【刷新当前页面】一次，待页面加载完成后再点击下载。");
        return;
    }

    // 获取数据
    const json = await fetchTweetData(tweetId);
    
    if (json === "REFRESH_REQUIRED") {
        showAlert(tab.id, "API 模板已过期或未找到。\n请刷新页面以重新捕获。");
        return;
    }

    if (!json) {
        showAlert(tab.id, "获取数据失败。\n请检查您的网络，或确保您已登录并能查看此推文。");
        return;
    }

    // 解析视频
    const videoUrl = extractVideoUrl(json);

    if (videoUrl) {
        console.log("Found video:", videoUrl);
        chrome.downloads.download({
            url: videoUrl,
            filename: `twitter_${tweetId}.mp4`,
            saveAs: false
        });
    } else {
        showAlert(tab.id, "无法解析视频地址。\n这可能是一个不支持下载的纯外链广告，或 Twitter 未提供原始视频文件。");
    }
}

// 辅助：在页面弹窗提示
function showAlert(tabId, message) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: (msg) => alert(msg),
        args: [message]
    });
}

chrome.action.onClicked.addListener(handleDownload);
